﻿namespace ILGenerator
{
    public enum CustomTypeBaseFlags
    {
        AddIInitializeableImplementation
    }
}
