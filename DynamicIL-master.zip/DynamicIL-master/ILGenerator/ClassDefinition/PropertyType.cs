﻿namespace ILGenerator.ClassDefinition
{
    public enum PropertyType
    {
        SystemType,
        DefinitionType,
        CollectionOfSystemType,
        CollectionOfDefinitionType
    }

}
