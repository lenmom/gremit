LearningEmit
============

A simple demo of Emit.
