using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PowerEmit.Test")]