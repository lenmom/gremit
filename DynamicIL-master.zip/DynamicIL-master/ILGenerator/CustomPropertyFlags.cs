﻿namespace ILGenerator
{
    public enum CustomPropertyFlags
    {
        InitializeInInitializeMethod
    }
}
