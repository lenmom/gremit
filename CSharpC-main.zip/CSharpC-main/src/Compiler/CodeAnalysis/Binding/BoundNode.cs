namespace Compiler.CodeAnalysis.Binding;

public abstract record BoundNode;
