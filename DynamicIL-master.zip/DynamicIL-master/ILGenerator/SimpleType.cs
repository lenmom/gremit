﻿namespace ILGenerator
{
    public class SimpleType : CustomTypeBase
    {
        public SimpleType(BuildContext bc, string name) : base(bc, name)
        {

        }
    }
}
