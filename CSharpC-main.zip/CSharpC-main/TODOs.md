### TODOs
* [ ] Refactor SyntaxToken: Remove value from SyntaxToken record, add explicit values to tokens
* [ ] Support escape character in character parsing
