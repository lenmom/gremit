﻿using System.Resources;
using System.Reflection;
using System.Runtime.InteropServices;

// Assembly-specific attributes

[assembly: AssemblyTitle("FasterflectSample")]
[assembly: Guid("4b8adab7-4b50-439e-95a2-411144626bc2")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: NeutralResourcesLanguage("en-BW")]
