﻿#region License

// Copyright © 2010 Buu Nguyen, Morten Mertner
// Copyright © 2018 Wesley Hamilton
// 
// Licensed under the Apache License, Version 2.0 (the "License"); 
// you may not use this file except in compliance with the License. 
// You may obtain a copy of the License at 
// 
// http://www.apache.org/licenses/LICENSE-2.0 
// 
// Unless required by applicable law or agreed to in writing, software 
// distributed under the License is distributed on an "AS IS" BASIS, 
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
// See the License for the specific language governing permissions and 
// limitations under the License.
// 
// The latest version of this file can be found at https://github.com/ffhighwind/fasterflect

#endregion

using System;
using System.Diagnostics;
using System.Reflection;

namespace Fasterflect.Emitter
{
	[DebuggerStepThrough]
	internal class CtorInfo
	{
		public CtorInfo(Type targetType, FasterflectFlags bindingFlags, Type[] parameterTypes)
		{
			TargetType = targetType;
			BindingFlags = bindingFlags;
			ParameterTypes = parameterTypes;
		}

		public Type TargetType { get; }
		public FasterflectFlags BindingFlags { get; }
		public Type[] ParameterTypes { get; }

		public override bool Equals(object obj)
		{
			if (obj is CtorInfo other &&
				ParameterTypes.Length == other.ParameterTypes.Length &&
				TargetType.Equals(other.TargetType) &&
				BindingFlags == other.BindingFlags) {
				for (int i = 0, count = ParameterTypes.Length; i < count; ++i) {
					if (!ParameterTypes[i].Equals(other.ParameterTypes[i])) {
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public override int GetHashCode()
		{
			int hashCode = -25691114;
			hashCode = hashCode * -1521134295 + TargetType.GetHashCode();
			hashCode = hashCode * -1521134295 + BindingFlags.GetHashCode();
			for (int i = 0, count = ParameterTypes.Length; i < count; ++i) {
				hashCode = hashCode * -1521134295 + ParameterTypes[i].GetHashCode();
			}
			return hashCode;
		}
	}
}
