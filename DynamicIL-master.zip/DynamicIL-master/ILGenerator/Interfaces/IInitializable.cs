﻿namespace ILGenerator.Interfaces
{
    public interface IInitializable
    {
        void Initialize();

    }
}
