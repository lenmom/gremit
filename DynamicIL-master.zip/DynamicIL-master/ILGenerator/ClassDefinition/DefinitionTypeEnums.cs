﻿namespace ILGenerator.ClassDefinition
{
    public enum DefinitionTypeEnums
    {
        SimpleType,
        NotifyPropertyChanged,
        NotifyPropertyChangedWithChangeTracker
    }

}
