# Fast.Reflection
Extension methods library emitting IL to generate delegates for fast reflection

View Unity Forum thread for readme/doc and see Sample Unity scene for benchmarks/examples
http://forum.unity3d.com/threads/open-source-fast-reflection-delegates-for-lightning-fast-metadata-reflection.305080/
