//EXPECTED:c

void main()
{
    Write('c');
}