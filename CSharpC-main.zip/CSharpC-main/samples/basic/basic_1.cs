//EXPECTED:5

void main()
{
    Write(5);
}