namespace Compiler.CodeAnalysis.Binding
{
    public enum BoundUnaryOperatorKind
    {
        Identity,
        Negation,
        LogicalNegation,
    }
}