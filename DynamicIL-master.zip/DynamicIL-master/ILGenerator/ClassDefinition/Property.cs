﻿namespace ILGenerator.ClassDefinition
{
    public class Property
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public bool AutoInitialize { get; set; }
    }

}
