﻿using System.Reflection;
using System.Runtime.InteropServices;

// Assembly-specific attributes

[assembly: AssemblyTitle("FasterflectPlayground")]
[assembly: Guid("919425e7-3e0f-4c37-ad48-baaeba10afad")]
