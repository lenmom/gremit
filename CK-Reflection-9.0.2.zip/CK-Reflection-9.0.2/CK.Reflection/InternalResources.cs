﻿using System;

namespace CK.Reflection
{
    /// <summary>
    /// Resource class, for looking up strings.
    /// </summary>
    internal class InternalResources
    {
        public static readonly string InterfaceTypeExpected = "The given type must be the Type of an interface..";
    }
}
